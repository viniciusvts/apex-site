<?php

namespace MikadoCore\CPT\Testimonials\Shortcodes;


use MikadoCore\Lib;
/**
 * Class Testimonials
 * @package MikadoCore\CPT\Testimonials\Shortcodes
 */
class Testimonials implements Lib\ShortcodeInterface {
    /**
     * @var string
     */
    private $base;
	
    public function __construct() {
        $this->base = 'no_testimonials';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    /**
     * Returns base for shortcode
     * @return string
     */
    public function getBase() {
        return $this->base;
    }

    /**
     * Maps shortcode to Visual Composer
     *
     * @see vc_map()
     */
    public function vcMap() {
        if(function_exists('vc_map')) {
			global $mkd_burst_IconCollections;
			
			$icons_array= array();
			if(mkd_core_theme_installed()) {
				$icons_array = $mkd_burst_IconCollections->getVCParamsArray(array("element" => "testimonial_type", "value" => array("with_icon")), '', false);
			}
			
            vc_map( array(
                "name" => "Testimonials",
                "base" => $this->base,
                "category" => 'by MIKADO',
                "icon" => "icon-wpb-testimonials extended-custom-icon",
                "allowed_container_element" => 'vc_row',
                "params" => array_merge(
					array(
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Type",
							"param_name" => "testimonial_type",
							"value" => array(
								"Vertically Aligned" => "image_above",
								"Horizontally Aligned" => "image_left",
								"Horizontally Aligned With Icon" => "with_icon",
								"Carousel" => "testimonial_type_carousel"
							),
							"save_always" => true,
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Category",
							"param_name" => "category",
							"value" => "",
							"description" => "Category Slug (leave empty for all)"
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Number",
							"param_name" => "number",
							"value" => "",
							"description" => "Number of Testimonials"
						),
					),
					$icons_array,
					array(
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Icon Font Size",
							"param_name" => "icon_font_size",
							"value" => "",
							"description" => "",
							"dependency" => array("element" => "testimonial_type", "value" => array("with_icon"))
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Icon Color",
							"param_name" => "icon_color",
							"description" => "",
							"dependency" => array("element" => "testimonial_type", "value" => array("with_icon"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Title",
							"param_name" => "show_title",
							"value" => array(
								"Yes" => "yes",
								"No" => "no"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"with_icon",
									"image_left",
									"image_above"
								)
							)
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Title Color",
							"param_name" => "title_color",
							"description" => "",
							"dependency" => array("element" => "show_title", "value" => array("yes"))
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Background Color",
							"param_name" => "background_color",
							"description" => "Set testimonial background color."
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Title Separator",
							"param_name" => "show_title_separator",
							"value" => array(
								"No" => "no",
								"Yes" => "yes"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"with_icon",
									"image_left",
									"image_above"
								)
							)
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Separator Color",
							"param_name" => "testimonials_carousel_separator_color",
							"save_always" => true,
							"description" => "",
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"testimonial_type_carousel"
								)
							)
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Separator Color",
							"param_name" => "separator_color",
							"description" => "",
							"dependency" => array("element" => "show_title_separator", "value" => array("yes"))
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Separator Width",
							"param_name" => "separator_width",
							"description" => "",
							"dependency" => array("element" => "show_title_separator", "value" => array("yes"))
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Separator Height",
							"param_name" => "separator_height",
							"description" => "",
							"dependency" => array("element" => "show_title_separator", "value" => array("yes"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Align",
							"param_name" => "text_align",
							"value" => array(
								"Left"   => "left_align",
								"Center" => "center_align",
								"Right"  => "right_align"
							),
							"save_always" => true,
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"with_icon",
									"image_left",
									"image_above"
								)
							)
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Color",
							"param_name" => "text_color",
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Font Family",
							"param_name" => "text_font_family",
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Font Size",
							"param_name" => "text_font_size",
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Line Height (px)",
							"param_name" => "text_line_height",
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Font Style",
							"param_name" => "text_font_style",
							"value" => array(
								"" => "",
								"Normal" => "normal",
								"Italic" => "italic"
							)
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Letter spacing (px)",
							"param_name" => "text_letter_spacing",
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Top Padding",
							"param_name" => "text_top_padding",
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Text Bottom Padding",
							"param_name" => "text_bottom_padding",
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Author",
							"param_name" => "show_author",
							"value" => array(
								"Yes" => "yes",
								"No" => "no"
							),
							"save_always" => true,
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Position",
							"param_name" => "author_position",
							"value" => array(
								"Below Text" => "below_text",
								"Above Text" => "above_text"
							),
							"save_always" => true,
							"description" => "This option doesn't work when Carousel type is selected.",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Text Font Family",
							"param_name" => "author_text_font_family",
							"description" => "",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Text Color",
							"param_name" => "author_text_color",
							"description" => "",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Font Size (px)",
							"param_name" => "author_font_size",
							"description" => "",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Letter Spacing (px)",
							"param_name" => "author_letter_spacing",
							"description" => "",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Font Weigth",
							"param_name" => "author_font_weight",
							"value" => array(
								"Default" => "",
								"Thin 100" => "100",
								"Extra-Light 200" => "200",
								"Light 300" => "300",
								"Regular 400" => "400",
								"Medium 500" => "500",
								"Semi-Bold 600" => "600",
								"Bold 700" => "700",
								"Extra-Bold 800" => "800",
								"Ultra-Bold 900" => "900"
							),
							"description" => "",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Author Font Style",
							"param_name" => "author_font_style",
							"value" => array(
								"" => "",
								"Normal" => "normal",
								"Italic" => "italic"
							),
							"description" => "",
							"dependency" => array("element" => "show_author", "value" => array("yes"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Author Job Position",
							"param_name" => "show_position",
							"value" => array(
								"No" => "no",
								"Yes" => "yes"
							),
							"save_always" => true,
							"dependency" => array("element" => "show_author", "value" => array("yes")),
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Job Position Placement",
							"param_name" => "job_position_placement",
							"value" => array(
								"In line with name" => "inline",
								"Below name" => "below"
							),
							"save_always" => true,
							"dependency" => array("element" => "show_position", "value" => array("yes")),
							"description" => "This option doesn't work when Carousel type is selected."
						),
						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Job Color",
							"param_name" => "job_color",
							"dependency" => array("element" => "show_position", "value" => array("yes")),
							"description" => ""
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Job Font size (px)",
							"param_name" => "job_font_size",
							"dependency" => array("element" => "show_position", "value" => array("yes")),
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Job Font style",
							"param_name" => "job_font_style",
							"value" => array(
								"" => "",
								"Normal" => "normal",
								"Italic" => "italic"
							),
							"dependency" => array("element" => "show_position", "value" => array("yes")),
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Image",
							"param_name" => "show_image",
							"value" => array(
								"Yes" => "yes",
								"No" => "no"
							),
							"save_always" => true,
							"dependency" => array(
								"element" => "testimonial_type",
								"value" => array(
									"image_above",
									"image_left"
								)
							),
							"description" => ""
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Image Position Related to Testimonial Content",
							"param_name" => "image_position",
							"value" => array(
								"Top" => "top",
								"Center" => "center",
								"Bottom" => "bottom"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array("element" => "testimonial_type", "value" => array("image_above"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Image Position Related to Testimonial Slide",
							"param_name" => "image_position_slide",
							"value" => array(
								"Over the Edge" => "over",
								"Inside" => "inside"
							),
							"save_always" => true,
							"description" => "Image size when the image position is over the edge of testimonial slide is fixed (113x113px). Image size when the image position is inside of testimonial slide is original.",
							"dependency" => array("element" => "image_position", "value" => array("top","bottom"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Image Border",
							"param_name" => "show_image_border",
							"value" => array(
								"No" => "no",
								"Yes" => "yes"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array("element" => "testimonial_type", "value" => array("image_above"))
						),

						array(
							"type" => "colorpicker",
							"holder" => "div",
							"class" => "",
							"heading" => "Image Border Color",
							"param_name" => "image_border_color",
							"description" => "",
							"dependency" => array("element" => "show_image_border", "value" => array("yes"))
						),

						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Image Border Width",
							"param_name" => "image_border_width",
							"description" => "",
							"dependency" => array("element" => "show_image_border", "value" => array("yes"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Navigation Arrows",
							"param_name" => "show_navigation_arrows",
							"value" => array(
								"No" => "no",
								"Yes" => "yes"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array("element" => "testimonial_type", "value" => array("image_above"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Testimonial Width",
							"param_name" => "testimonial_width",
							"value" => array(
								"Full Width" => "testimonial_full_width",
								"In Grid" => "testimonial_in_grid",
								"Content in Grid" => "testimonial_content_in_grid"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array("element" => "show_navigation_arrows", "value" => array("yes"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Show Navigation",
							"param_name" => "show_navigation",
							"value" => array(
								"No" => "no",
								"Yes" => "yes"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array("element" => "testimonial_type", "value" => array("image_above"))
						),
						
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Image Holder Width (%)",
							"param_name" => "image_holder_width",
							"dependency" => array("element" => "testimonial_type", "value" => array("image_left"))
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Choose Navigation Type",
							"param_name" => "navigation_type",
							"value" => array(
								"None" => "none",
								"Arrows" => "arrows",
								"Buttons" => "buttons"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"image_left",
									"testimonial_type_carousel"
								)
							)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Enable outer border around active button",
							"param_name" => "active_button_outer_border",
							"value" => array(
								"No" => "no",
								"Yes" => "yes"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array(
								"element" => "navigation_type", 
								"value" => array(
									"buttons"
								)
							)
						),
						array(
							"type" => "dropdown",
							"holder" => "div",
							"class" => "",
							"heading" => "Auto rotate slides",
							"param_name" => "auto_rotate_slides",
							"value" => array(
								"3"         => "3",
								"5"         => "5",
								"10"        => "10",
								"15"        => "15",
								"Disable"   => "0"
							),
							"save_always" => true,
							"description" => "",
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"with_icon",
									"image_left",
									"image_above"
								)
							)
						),
						array(
							"type" => "textfield",
							"holder" => "div",
							"class" => "",
							"heading" => "Animation speed",
							"param_name" => "animation_speed",
							"value" => "",
							"description" => __("Speed of slide animation in miliseconds"),
							"dependency" => array(
								"element" => "testimonial_type", 
								"value" => array(
									"with_icon",
									"image_left",
									"image_above"
								)
							)
						)
					)
				)
			) );
        }
    }

    /**
     * Renders shortcodes HTML
     *
     * @param $atts array of shortcode params
     * @param $content string shortcode content
     * @return string
     */
    public function render($atts, $content = null) {
        global $mkd_burst_options;
        global $mkd_burst_IconCollections;

        $deafult_args = array(
			"testimonial_type" => "image_above",
            "number" => "-1",
            "category" => "",
            "icon_font_size" => "",
            "icon_color" => "",
            "background_color" => "",
            "show_title" => "",
            "title_color" => "",
            "testimonials_carousel_separator_color" => "",
            "show_title_separator" => "no",
            "separator_color" => "",
            "separator_width" => "",
            "separator_height" => "",
            "text_color" => "",
            "text_font_size" => "",
			"text_font_family" => "",
            "text_line_height" => "",
            "text_font_style" => "",
            "text_letter_spacing" => "",
			"text_top_padding" => "",
			"text_bottom_padding" => "",
            "show_author" => "yes",
            "author_position" => "below_text",
            "author_text_color" => "",
			"author_text_font_family" => "",
            "author_font_size" => "",
            "author_letter_spacing" => "",
			"author_font_weight" => "",
			"author_font_style" => "",
            "show_position" => "no",
            "job_position_placement" => "",
            "job_color" => "",
            "job_font_size" => "",
            "job_font_style" => "",
            "text_align" => "left_align",
            "show_navigation" => "no",
            "show_navigation_arrows" => "no",
            "testimonial_width" => "testimonial_full_width",
            "navigation_type" => "arrows",
            "active_button_outer_border" => "no",
            "auto_rotate_slides" => "",
            "animation_speed" => "",			
			"image_holder_width" => "",
            "show_image" => "yes",
            "image_position" => "top",
            "show_image_border" => "no",
            "image_border_color" => "",
            "image_border_width" => "",
            "image_position_slide" => ""
        );
		
		$args = array_merge($deafult_args, $mkd_burst_IconCollections->getShortcodeParams());

        extract(shortcode_atts($args, $atts));
		
        $number = esc_attr($number);
        $category = esc_attr($category);
        $icon_font_size = esc_attr($icon_font_size);
        $icon_color = esc_attr($icon_color);
        $background_color = esc_attr($background_color);
        $title_color = esc_attr($title_color);
        $testimonials_carousel_separator_color = esc_attr($testimonials_carousel_separator_color);
        $separator_color = esc_attr($separator_color);
        $separator_width = esc_attr($separator_width);
        $separator_height = esc_attr($separator_height);
        $text_color = esc_attr($text_color);
		$text_font_family = esc_attr($text_font_family);
        $text_font_size = esc_attr($text_font_size);
        $text_font_style = esc_attr($text_font_style);
        $text_letter_spacing = esc_attr($text_letter_spacing);
		$text_top_padding = esc_attr($text_top_padding);
		$text_bottom_padding = esc_attr($text_bottom_padding);
        $author_text_color = esc_attr($author_text_color);
		$author_text_font_family = esc_attr($author_text_font_family);
		$author_font_weight = esc_attr($author_font_weight);
		$author_font_style = esc_attr($author_font_style);
        $job_color = esc_attr($job_color);
        $job_font_size = esc_attr($job_font_size);
        $job_font_style = esc_attr($job_font_style);
        $animation_speed = esc_attr($animation_speed);
        $image_border_color = esc_attr($image_border_color);
        $image_border_width = esc_attr($image_border_width);
		$image_holder_width =  esc_attr($image_holder_width);
		
        $html = "";
        $html_author = "";		
        $add_icon = '';
        $additional_styles = "";
        $testimonial_p_style = "";
        $testimonial_separator_style = "";
        $testimonial_title_style = "";
        $testimonial_icon_style = "";
        $navigation_button_radius = "";
		$navigation_button_classes = "";
        $testimonial_name_styles = "";
        $testimonials_clasess = "";
        $image_clasess = "";
        $ul_classes = "";
        $testimonial_image_border_style = "";
        $job_style = "";
		$data_attr = '';

        if ($testimonial_type == "image_left") {
	        if ($navigation_type != 'none') {
	        	if ($navigation_type == 'arrows') {
	        		$show_navigation_arrows = 'yes';
	        		$show_navigation = 'no';
	        	}
	        	else {
	        		$show_navigation_arrows = 'no';
	        		$show_navigation = 'yes';
	        	}
	        }
		}
		
		if($active_button_outer_border == 'yes'){
			$navigation_button_classes .= 'button_with_border';
		}

        if ($show_navigation_arrows == "yes") {
            $testimonials_clasess .= ' with_arrows ';
			$testimonials_clasess .= $testimonial_width;
			if($testimonial_width == 'testimonial_content_in_grid') {
				$testimonials_clasess .= ' grid_section';
				$ul_classes .= " section_inner";
			}
        }

		if ($testimonial_type != "") {
			$testimonials_clasess .= ' ' . $testimonial_type;
		}

		if ($show_image == "yes") {
			$testimonials_clasess .= ' show_images';
		}
		
		if($image_holder_width != '' && $testimonial_type == "image_left"){
			$data_attr .= " data-image-holder-width ='" . $image_holder_width . "'";
		}

        if ($testimonial_type == 'image_above'){
	        if ($show_image == "yes" && $image_position == "top") {
	            $image_clasess .= ' image_top';
	        }

	        if ($show_image == "yes" && $image_position == "bottom") {
	            $image_clasess .= ' image_bottom';
	        }
			
			if ($show_image == "yes" && $image_position == "center") {
	            $image_clasess .= ' image_center';
	        }

	        if ($show_image == "yes" && $image_position_slide == "inside") {
	            $image_clasess .= ' relative_position';
	        }

	        if ($show_image == "yes" && $image_position_slide == "over") {
	            $image_clasess .= ' absolute_position';
	        }
	    }

        if ($separator_color != "") {
            $testimonial_separator_style .= "background-color: " . $separator_color . ";";
        }
        if ($separator_width != "") {
            $testimonial_separator_style .= "width: " . $separator_width . "px;";
        }
        if ($separator_height != "") {
            $testimonial_separator_style .= "height: " . $separator_height . "px;";
        }
        if ($title_color != "") {
            $testimonial_title_style .= "color: " . $title_color . ";";
        }

		if ($background_color != "") {
			$additional_styles .= "background-color: " .$background_color . "; ";
		}

        if ( $show_image_border == "yes" ) {
            if ($image_border_color != "") {
                $testimonial_image_border_style .= "border-color: " . $image_border_color . ";";
            }

            if ($image_border_width != "") {
                $testimonial_image_border_style .= "border-width: " . $image_border_width . "px;";
            }
        }
		
		if ($icon_pack != "") {
			$testimonial_icon_style = '';
			$icon_collection_obj = $mkd_burst_IconCollections->getIconCollection($icon_pack);

			if ($icon_font_size != "") {
				$testimonial_icon_style .= 'font-size: ' . $icon_font_size . 'px;';
			}
			
			if ($icon_color != "") {
				$testimonial_icon_style .= "color:" . $icon_color . ";";
			}

			if (method_exists($icon_collection_obj, 'render')) {
				$add_icon .= $icon_collection_obj->render(${$icon_collection_obj->param}, array(
					'icon_attributes' => array(
						'style' => $testimonial_icon_style,
						'class' => 'show_load_more_icon'
					)
				));
			}

		}

        if ($text_font_size != "" || $text_color != "" || $text_top_padding != "" || $text_bottom_padding != "" || $text_font_style != ""|| $text_letter_spacing != "" || $text_line_height != "" || $text_font_family !="") {
            $testimonial_p_style = " style='";
			if ($text_font_family != "") {
                $testimonial_p_style .= "font-family:" . $text_font_family . "!important;";
            }
            if ($text_font_size != "") {
                $testimonial_p_style .= "font-size:" . $text_font_size . "px;";
            }
            if ($text_font_style != "") {
                $testimonial_p_style .= "font-style:" . $text_font_style . ";";
            }
			if ($text_letter_spacing != "") {
                $testimonial_p_style .= "letter-spacing:" . $text_letter_spacing . "px;";
            }
			if ($text_line_height != "") {
				$text_line_height = (strstr($text_line_height, 'px', true)) ? $text_line_height : $text_line_height . 'px';
				$testimonial_p_style .= "line-height:" . $text_line_height . ";";
			}
            if ($text_color != "") {
                $testimonial_p_style .= "color:" . $text_color . ";";
            }
            if ($text_top_padding != "") {
				$testimonial_p_style .= "padding-top:" . $text_top_padding . "px;";
			}
			if ($text_bottom_padding != "") {
				 $testimonial_p_style .= "padding-bottom:" . $text_bottom_padding . "px;";
			}
            $testimonial_p_style .= "'";
        }

        if ($author_text_color != "") {
            $testimonial_name_styles .= "color: " . $author_text_color . ";";
        }
		if ($author_text_font_family != "") {
            $testimonial_name_styles .= "font-family: " . $author_text_font_family . ";";
        }
        if ($author_font_size != "") {
            $author_font_size = (strstr($author_font_size, 'px', true)) ? $author_font_size : $author_font_size . 'px';
            $testimonial_name_styles .= "font-size: " . $author_font_size . ";";
        }
		if ($author_letter_spacing != "") {
            $author_letter_spacing = (strstr($author_letter_spacing, 'px', true)) ? $author_letter_spacing : $author_letter_spacing . 'px';
            $testimonial_name_styles .= "letter-spacing: " . $author_letter_spacing . ";";
        }		
		if ($author_font_weight != "") {
            $testimonial_name_styles .= "font-weight: " . $author_font_weight . ";";
        }
		if ($author_font_style != "") {
            $testimonial_name_styles .= "font-style: " . $author_font_style . ";";
        }

        if ($job_color != "") {
            $job_style .= 'color: '.$job_color.';';
        }
        if ($job_font_size != "") {
            $job_font_size = (strstr($job_font_size, 'px', true)) ? $job_font_size : $job_font_size . 'px';
            $job_style .= 'font-size: '.$job_font_size.'px;';
        }
        if ($job_font_style != "") {
            $job_style .= 'font-style: '.$job_font_style.';';
        }

        $args = array(
            'post_type' => 'testimonials',
            'orderby' => "date",
            'order' => "DESC",
            'posts_per_page' => $number
        );

        if ($category != "") {
            $args['testimonials_category'] = $category;
        }


        
		if($show_navigation_arrows == "yes" && $testimonial_width == 'testimonial_in_grid') {
			$html .= "<div class='testimonials_holder grid_section clearfix'>";
			$html .= "<div class='testimonials_grid_holder section_inner'>";
		}
		else if($testimonial_type != "" && $testimonial_type=="testimonial_type_carousel") {
			$html .= "<div class='testimonials_holder testimonials_type_carousel_holder clearfix'>";
		}
		else {
			$html .= "<div class='testimonials_holder clearfix'>";
		}
        $html .= '<div class="testimonials testimonials_carousel ' . $testimonials_clasess . ' '. $navigation_button_classes . '" data-show-navigation="' . $show_navigation . '" data-show-navigation-arrows="' . $show_navigation_arrows . '" data-animation-speed="' . $animation_speed . '" data-auto-rotate-slides="' . $auto_rotate_slides . '">';
        $html .= '<ul class="slides '. $ul_classes .'">';

        query_posts($args);
        if (have_posts()) :
            while (have_posts()) : the_post();
                $author = get_post_meta(get_the_ID(), "mkd_testimonial-author", true);
                $text = get_post_meta(get_the_ID(), "mkd_testimonial-text", true);
                $title = get_post_meta(get_the_ID(), "mkd_testimonial_title", true);
                $job = get_post_meta(get_the_ID(), "mkd_testimonial_author_position", true);


                $html .= '<li id="testimonials' . get_the_ID() . '" class="testimonial_content ' . $text_align . ' ' . $image_clasess .'" style="' . $additional_styles .'">';

                switch ($testimonial_type) {
                	case 'image_left':
                		
                		$html .= '<div class = "testimonial_image_left_holder" '.$data_attr.'>';
		                if ($show_image == "yes" && has_post_thumbnail(get_the_ID())) {
		                    $html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
		                }
		                $html .= '<div class="testimonial_content_inner"';

		                $html .= '>';
		                $html .= '<div class="testimonial_text_holder ' . $text_align . '">';

		                if ($show_author == "yes") {
		                    $html_author = '<p class="testimonial_author" style="' . $testimonial_name_styles . '">- ' . $author;
		                    if ($show_position == "yes" && $job !== '') {
		                        if( $job_position_placement == "inline" ) {
		                            $html_author .= ', <span class="testimonials_job" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                        elseif ( $job_position_placement == "below") {
		                            $html_author .= '<span class="testimonials_job below" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                    }
		                    $html_author .= '</p>';
		                }

		                $testimonial_text_inner_class = '';
		                if($show_title == "no") {
		                    $testimonial_text_inner_class .= ' without_title';
		                }

		                $html .= '<div class="testimonial_text_inner'. $testimonial_text_inner_class .'">';
		                if ($show_title == "yes") {
		                    $html .= '<p class="testimonial_title" style="' . $testimonial_title_style . '">' . $title . '</p>';
		                }
		                if ($show_title_separator == "yes") {
		                    $html .= '<span class="testimonial_separator" style="' . $testimonial_separator_style . '"></span>';
		                }
		                if ($author_position == "below_text") {
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
		                    $html .= $html_author;
		                } elseif ($author_position == "above_text") {
		                    $html .= $html_author;
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
		                }


		                $html .= '</div>'; //close testimonial_text_inner
		                $html .= '</div>'; //close testimonial_text_holder
		                $html .= '</div>'; //close testimonial_image_left_holder

		                $html .= '</div>'; //close testimonial_content_inner
		                break;
                	
                	case 'image_above':
                		if ($show_image == "yes" && !$image_position == "center" && !($image_position == "bottom" && $image_position_slide == "inside")) {
		                    $html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
		                }
		                $html .= '<div class="testimonial_content_inner"';

		                $html .= '>';
		                $html .= '<div class="testimonial_text_holder ' . $text_align . '">';

		                if ($show_author == "yes") {
		                    $html_author = '<p class="testimonial_author" style="' . $testimonial_name_styles . '">- ' . $author;
		                    if ($show_position == "yes" && $job !== '') {
		                        if( $job_position_placement == "inline" ) {
		                            $html_author .= ', <span class="testimonials_job" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                        elseif ( $job_position_placement == "below") {
		                            $html_author .= '<span class="testimonials_job below" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                    }
		                    $html_author .= '</p>';
		                }

		                $testimonial_text_inner_class = '';
		                if($show_title == "no") {
		                    $testimonial_text_inner_class .= ' without_title';
		                }

		                $html .= '<div class="testimonial_text_inner'. $testimonial_text_inner_class .'">';
		                if ($show_title == "yes") {
		                    $html .= '<p class="testimonial_title" style="' . $testimonial_title_style . '">' . $title . '</p>';
		                }
		                if ($show_title_separator == "yes") {
		                    $html .= '<span class="testimonial_separator" style="' . $testimonial_separator_style . '"></span>';
		                }
		                if ($author_position == "below_text") {
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
							if ($show_image == "yes" && $image_position == "center") {
								$html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
							}
		                    $html .= $html_author;
		                } elseif ($author_position == "above_text") {
		                    $html .= $html_author;
							if ($show_image == "yes" && $image_position == "center") {
								$html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
							}
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
		                }


		                $html .= '</div>'; //close testimonial_text_inner
		                $html .= '</div>'; //close testimonial_text_holder

		                $html .= '</div>'; //close testimonial_content_inner
		                if ($show_image == "yes" && $image_position == "bottom" && $image_position_slide == "inside") {
		                    $html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
		                }
                		break;
						
					case 'with_icon':
						$html .= '<div class = "testimonial_with_icon_holder" '.$data_attr.'>';			               
						$html .= '<div class="testimonial_icon_holder">';
						$html .= $add_icon;
						$html .= '</span>';							
						$html .= '</div>';		               
		                $html .= '<div class="testimonial_content_inner">';
		                $html .= '<div class="testimonial_text_holder ' . $text_align . '">';

		                if ($show_author == "yes") {
		                    $html_author = '<p class="testimonial_author" style="' . $testimonial_name_styles . '">- ' . $author;
		                    if ($show_position == "yes" && $job !== '') {
		                        if( $job_position_placement == "inline" ) {
		                            $html_author .= ', <span class="testimonials_job" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                        elseif ( $job_position_placement == "below") {
		                            $html_author .= '<span class="testimonials_job below" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                    }
		                    $html_author .= '</p>';
		                }

		                $testimonial_text_inner_class = '';
		                if($show_title == "no") {
		                    $testimonial_text_inner_class .= ' without_title';
		                }

		                $html .= '<div class="testimonial_text_inner'. $testimonial_text_inner_class .'">';
		                if ($show_title == "yes" && $title != "") {
		                    $html .= '<p class="testimonial_title" style="' . $testimonial_title_style . '">' . $title . '</p>';
		                }
		                if ($show_title_separator == "yes") {
		                    $html .= '<span class="testimonial_separator" style="' . $testimonial_separator_style . '"></span>';
		                }
		                if ($author_position == "below_text") {
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
		                    $html .= $html_author;
		                } elseif ($author_position == "above_text") {
		                    $html .= $html_author;
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
		                }


		                $html .= '</div>'; //close testimonial_text_inner
		                $html .= '</div>'; //close testimonial_text_holder
		                $html .= '</div>'; //close testimonial_image_left_holder

		                $html .= '</div>'; //close testimonial_content_inner
		                break;
						
					case 'testimonial_type_carousel':

						$testimonials_carousel_separator_styles = "";

						if ( $testimonials_carousel_separator_color != "") {

							$testimonials_carousel_separator_styles .= $testimonials_carousel_separator_color;

						}

						$html .= '<div class="top_color_holder"></div>'; //top color holder
						$html .= '<div class = "testimonial_type_carousel_container" '.$data_attr.'>'; //open single carousel
						$html .= '<div class="content_holder">'; //open carousel content holder
						$html .= '<div class = "testimonial_type_carousel_text_holder" style="border-bottom-color:'.$testimonials_carousel_separator_styles.' ;">'; // open text holder
						$html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
						$html .= '<div class="testimonial_type_carousel_triangle" style="border-color:'.$testimonials_carousel_separator_styles.'; background-color:'.$background_color.';"></div>';
						$html .= '</div>'; // closing text holder
						$html .= '<div class="testimonial_image_holder">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
						$html .= '<div class="testimonial_author_holder ' . $text_align . '">'; // open author holder
						$html .= '<p class="testimonial_author" style="' . $testimonial_name_styles . '"> ' . $author . '</p>';
						if ($job !== '' && $show_position == "yes") {
							$html .= '<p class="testimonials_job" style="'.$job_style.'">'.$job.'</p>';
		                }
						$html .= '</div>'; // close author holder
						$html .= '</div>'; // close carousel content holder
						$html .= '</div>'; // closing single carousel
					break;

                	default:
		                if ($show_image == "yes" && !$image_position == "center" &&  !($image_position == "bottom" && $image_position_slide == "inside")) {
		                    $html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
		                }
		                $html .= '<div class="testimonial_content_inner"';

		                $html .= '>';
		                $html .= '<div class="testimonial_text_holder ' . $text_align . '">';

		                if ($show_author == "yes") {
		                    $html_author = '<p class="testimonial_author" style="' . $testimonial_name_styles . '">- ' . $author;
		                    if ($show_position == "yes" && $job !== '') {
		                        if( $job_position_placement == "inline" ) {
		                            $html_author .= ', <span class="testimonials_job" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                        elseif ( $job_position_placement == "below") {
		                            $html_author .= '<span class="testimonials_job below" style="'.$job_style.'">'.$job.'</span>';
		                        }
		                    }
		                    $html_author .= '</p>';
		                }

		                $testimonial_text_inner_class = '';
		                if($show_title == "no") {
		                    $testimonial_text_inner_class .= ' without_title';
		                }

		                $html .= '<div class="testimonial_text_inner'. $testimonial_text_inner_class .'">';
		                if ($show_title == "yes") {
		                    $html .= '<p class="testimonial_title" style="' . $testimonial_title_style . '">' . $title . '</p>';
		                }
		                if ($show_title_separator == "yes") {
		                    $html .= '<span class="testimonial_separator" style="' . $testimonial_separator_style . '"></span>';
		                }
		                if ($author_position == "below_text") {
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
							if ($show_image == "yes" && $image_position == "center") {
								$html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
							}
		                    $html .= $html_author;
		                } elseif ($author_position == "above_text") {
		                    $html .= $html_author;
							if ($show_image == "yes" && $image_position == "center") {
								$html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
							}
		                    $html .= '<p class="testimonial_text"' . $testimonial_p_style . '>' . trim($text) . '</p>';
		                }


		                $html .= '</div>'; //close testimonial_text_inner
		                $html .= '</div>'; //close testimonial_text_holder

		                $html .= '</div>'; //close testimonial_content_inner
		                if ($show_image == "yes" && $image_position == "bottom" && $image_position_slide == "inside") {
		                    $html .= '<div class="testimonial_image_holder" style="' . $testimonial_image_border_style . '">' . get_the_post_thumbnail(get_the_ID()) . '</div>';
		                }
                		break;
                }

                $html .= '</li>'; //close testimonials
            endwhile;
        else:
            $html .= __('Sorry, no posts matched your criteria.', 'mkd_core');
        endif;

        wp_reset_query();
        $html .= '</ul>'; //close slides
		if($testimonial_type == 'testimonial_type_carousel') {
			if ($navigation_type != 'none') {
				if ($navigation_type == 'arrows') {
					$html .= '<ul class="caroufredsel-direction-nav"><li><a id="caroufredsel-prev" class="caroufredsel-prev" href="#"><span class="fa fa-angle-left"></span></a></li><li><a class="caroufredsel-next" id="caroufredsel-next" href="#"><span class="fa fa-angle-right"></span></a></li></ul>';
				}
				if ($navigation_type == 'buttons') {
					$html .= '<div id="testimonial_slider_pager" class="testimonial_slider_pager ' . $navigation_button_classes .'"></div>';
				}
			}
		}
        $html .= '</div>';
		if($show_navigation_arrows == "yes" && $testimonial_width == 'testimonial_in_grid') {
			$html .= '</div>';
		}
        $html .= '</div>';
        return $html;
    }
}